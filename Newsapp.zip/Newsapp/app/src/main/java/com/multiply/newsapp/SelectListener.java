package com.multiply.newsapp;

import com.multiply.newsapp.models.NewsHeadlines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadlines headlines);
}
